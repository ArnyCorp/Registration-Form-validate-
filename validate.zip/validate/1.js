function validate() {
    var userName = document.getElementById("userName");
    var lastName = document.getElementById("lastName");
    var datepicker = document.getElementById("datepicker");
    var email = document.getElementById("email");
    var pass = document.getElementById("pass");
    var address = document.getElementById("address");

    if(!userName.value) {

        return false;
    }
    if(!lastName.value) {

        return false;
    }
    if(!datepicker.value) {

        return false;
    }
    if(!email.value) {

        return false;
    }
    if(!pass.value) {

        return false;
    }
    if(!address.value) {

        return false;
    }

    alert('Validation passed.');
    return true;
}
